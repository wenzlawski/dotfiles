(key) @keyword
(value) @string
